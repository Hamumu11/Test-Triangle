
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;

public class Triangle extends JComponent {
		
	public static int colorIndex[] = {1,1,1,1,1,1};
	
	private double mX1 = -1;
	private double mY1 = -1;
	
	private double mX2 = -1;
	private double mY2 = -1;
	
	private double mX3 = -1;
	private double mY3 = -1;
	
	private double[] points = new double[6];
	
	public static int index = 0;
	
	private int finalX = -1;
	private int finalY = -1;

	private double distance(double x1, double y1, double x2, double y2) {
		return Math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
	}
	
	public Triangle() {
		super();
		setBackground(Color.WHITE);
		addMouseMotionListener(new MouseMotionListener() {

			@Override
			public void mouseDragged(MouseEvent e) {
				// TODO Auto-generated method stub
				if (finalX != -1 && finalY != -1) {
					points[finalX] = e.getX();
						points[finalY] = e.getY();
					repaint();
				}
			}

			@Override
			public void mouseMoved(MouseEvent e) {

			}

		});
		addMouseListener(new MouseListener() {

			@Override
			public void mouseClicked(MouseEvent e) {
				if (index < points.length) {
					
					points[index] = e.getX();
					
					points[index + 1] = e.getY();
					index = index + 2;
					repaint();
				}
			}

			@Override
			public void mousePressed(MouseEvent e) {
				int currentX = e.getX();
				int currentY = e.getY();
				for (int i = 0; i < index; i += 2) {
					if (points[i] - 5 < currentX && currentX < points[i] + 5 && points[i + 1] - 5 < currentY && currentY < points[i + 1] + 5) {
						finalX = i;
						finalY = i + 1;
						break;
					}
				}
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				finalX = -1;
				finalY = -1;
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub

			}

		});
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor(getBackground());
		g2d.fillRect(getBounds().x, getBounds().y, getBounds().width, getBounds().height);
		
		
		
		if (index > 0) {
			for (int i = 0; i < index; i += 2) {
				if(colorIndex[i] == 0) {
					g2d.setColor(Color.black);
				}
				if(colorIndex[i] == 1) {
					g2d.setColor(Color.red);
				}
				if(colorIndex[i] == 2) {
					g2d.setColor(Color.blue);
				}
				if(colorIndex[i] == 3) {
					g2d.setColor(Color.green);
				}
				if(colorIndex[i] == 4) {
					g2d.setColor(Color.white);
				}
				Ellipse2D ellipse = new Ellipse2D.Double(points[i] - 5, points[i + 1] - 5, 10, 10);
				g2d.draw(ellipse);
				g2d.fill(ellipse);
			}
		}
		if (index == 6) {
			g2d.setColor(Color.BLACK);
			
			Line2D line1 = new Line2D.Double(points[0], points[1], points[2], points[3]);
			g2d.draw(line1);
			
			Line2D line2 = new Line2D.Double(points[2], points[3], points[4], points[5]);
			g2d.draw(line2);
			Line2D line3 = new Line2D.Double(points[4], points[5], points[0], points[1]);
			g2d.draw(line3);
			
		}
		
	}
}