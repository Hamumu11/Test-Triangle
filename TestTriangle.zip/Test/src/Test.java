
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
public class Test extends Triangle{
	
	public static void main(String[] args) {
	JFrame window = new JFrame("GUI App");
	window.setBounds(200, 200, 500, 750);
	window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	window.setVisible(true);
	window.setLayout(null);
	
	Triangle p = new Triangle();
	p.setBounds(10, 10, 300, 300);
	p.setBackground(Color.white);
	window.add(p);
	
	JButton button1 = new JButton("BLACK");
	button1.setBounds(330,20,80,80);
	button1.setBackground(Color.black);
	button1.addActionListener(new ActionListener() { 
		  public void actionPerformed(ActionEvent e) { 
			  for(int i = index;i < colorIndex.length;i++) {
				  colorIndex[i] = 0;
			  }
		  } 
	});
	window.add(button1);
	
	JButton button2 = new JButton("RED");
	button2.setBounds(330,100,80,80);
	button2.setBackground(Color.red);
	button2.addActionListener(new ActionListener() { 
		  public void actionPerformed(ActionEvent e) { 
			  for(int i = index;i < colorIndex.length;i++) {
				  colorIndex[i] = 1;
			  }
		  } 
	});
	window.add(button2);
	
	JButton button3 = new JButton("BLUE");
	button3.setBounds(330,180,80,80);
	button3.setBackground(Color.blue);
	button3.addActionListener(new ActionListener() { 
		  public void actionPerformed(ActionEvent e) { 
			  for(int i = index;i < colorIndex.length;i++) {
				  colorIndex[i] = 2;
			  }
		  } 
	});
	window.add(button3);
	
	JButton button4 = new JButton("GREEN");
	button4.setBounds(330,260,80,80);
	button4.setBackground(Color.green);
	button4.addActionListener(new ActionListener() { 
		  public void actionPerformed(ActionEvent e) { 
			  for(int i = index;i < colorIndex.length;i++) {
				  colorIndex[i] = 3;
			  }
		  } 
	});
	window.add(button4);
	
	JButton button5 = new JButton("WHITE");
	button5.setBounds(330,340,80,80);
	button5.setBackground(Color.white);
	button5.addActionListener(new ActionListener() { 
		  public void actionPerformed(ActionEvent e) { 
			  for(int i = index;i < colorIndex.length;i++) {
				  colorIndex[i] = 4;
			  }
		  } 
	});
	window.add(button5);
}
}
